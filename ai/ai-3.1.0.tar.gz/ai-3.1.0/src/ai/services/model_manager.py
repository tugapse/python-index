# services/model_manager.py

import json
import os
import sys
from typing import Optional, Union 

import functions as func 

from entities.model_enums import ModelType, EngineType

from core.llms.base_llm import ModelParams, BaseModel

class EngineManager:
    """
    Manages the creation, loading, and saving of model configuration files,
    and handles the instantiation of model objects with environment checks.
    """

    @staticmethod
    def is_engine_installed(module_type: Union[ModelType,EngineType], module_name: str = "") -> bool:
        """
        Checks the installed_engines.json config manually by stepping up
        from src/ai/services/ to the project root.
        """
        root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
        config_path = os.path.join(root_dir, "installed_engines.json")
        
        # If the file isn't there, we assume nothing is installed
        if not os.path.exists(config_path):
            return False 

        # Mapping Enums to JSON IDs
        mapping = {
            ModelType.GGUF: "gguf",
            ModelType.OLLAMA: "ollama",
            ModelType.CAUSAL_LM: "transformers",
            ModelType.SEQ2SEQ_LM: "transformers",
            ModelType.OPEN_AI: "openai",
            ModelType.GEMINI: "gemini_api",
            EngineType.VOICE_ENGINE:"voice_engine",
            EngineType.VECTOR_MEMORY:"vector_memory"

        }

        engine_id = mapping.get(module_type)
        
        # Gemini logic: Split API vs Vertex
        if module_type == ModelType.GEMINI and "vertex" in module_name.lower():
            engine_id = "gemini_vertex"

        if not engine_id:
            return True # If it's a type we don't manage, let it through

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                installed_config = json.load(f)
                state = installed_config.get(engine_id, {})
                return state.get("installed", False)
        except Exception:
            return False # Fail safe

    @staticmethod
    def generate_default_config(
        model_name: str,
        model_type: ModelType
    ) -> dict:
        """
        Generates a default model configuration dictionary.
        """
        config = {
            "model_name": model_name,
            "model_type": model_type.value,
            "model_properties": {
                "max_new_tokens": 1024,
                "do_sample": True,
                "temperature": 0.7,
                "top_p": 0.95,
                "top_k": 50,
                "quantization_bits": 0
            }
        }

        if model_type == ModelType.SEQ2SEQ_LM:
            config["model_properties"]["temperature"] = 0.9
            config["model_properties"]["top_p"] = 0.9

        return config

    @staticmethod
    def load_config(filepath: str) -> dict:
        """
        Loads and parses a JSON model configuration file.
        """
        if not os.path.exists(filepath):
            func.error(f"Model configuration file '{filepath}' not found.", level="ERROR") 
            raise FileNotFoundError(f"Model configuration file '{filepath}' not found.")

        try:
            with open(filepath, 'r', encoding="utf-8") as f:
                model_config = json.load(f)
            func.log(f"Loaded model config from {filepath}") 
            return model_config
        except json.JSONDecodeError as e:
            func.error(f"Invalid JSON in '{filepath}'. Please check its format. Error: {e}", level="ERROR") 
            raise json.JSONDecodeError(f"Invalid JSON in '{filepath}'", e.doc, e.pos)
        except Exception as e:
            func.error(f"Failed to load model config from {filepath}: {e}", level="ERROR") 
            raise e

    @staticmethod
    def save_config(config: dict, filepath: str):
        """
        Saves a model configuration dictionary to a JSON file.
        """
        try:
            with open(filepath, 'w', encoding="utf-8") as f:
                json.dump(config, f, indent=2)
            func.log(f"Saved model config to {filepath}") 
        except Exception as e:
            func.error(f"Failed to save model config to {filepath}: {e}", level="ERROR") 
            raise e

    @staticmethod
    def load_model_instance(
        model_config: dict,
        system_prompt: str
    ) -> Optional[BaseModel]:
        """
        Loads and instantiates an LLM model based on the provided model configuration dictionary.
        """
        model_name = model_config.get("model_name")
        model_type_str = model_config.get("model_type")
        model_properties = model_config.get("model_properties", {})

        if not model_name or not model_type_str:
            func.log("'model_name' or 'model_type' missing in model configuration. Cannot load model.", level="ERROR") 
            return None

        try:
            model_type = ModelType(model_type_str)
        except ValueError:
            func.log(f"Unknown model_type '{model_type_str}' in model configuration.", level="ERROR")
            return None

        # If this returns False, we stop here and avoid the 'Lazy Import' crash.
        if not EngineManager.is_engine_installed(model_type, model_name):
            from color import Color
            func.error(
                f"The engine for {Color.YELLOW}{model_type.value}{Color.RED} is not installed.\n"
                f"Run '{Color.CYAN} ai --install{Color.RED}' to configure it.",
                level="ERROR"
            )
            return None

        func.log(f"Selected model: {model_name} (Type: {model_type.value})") 
        quantization_bits = model_properties.get("quantization_bits", 0)
        override_system_by_user_template = model_properties.get("override_system_by_user_template", False)
     
        model_params = ModelParams(**model_properties ).to_dict()

        other_llm_kwargs = {k: v for k, v in model_properties.items()
                            if k not in ["quantization_bits", "n_ctx", "n_gpu_layers", "verbose",
                                         "gguf_filename", "model_repo_id", "do_sample",
                                         "override_system_by_user_template", "azure_endpoint","api_key_name"]
                           }

        llm_instance: Optional[BaseModel] = None
        try:
            if model_type == ModelType.CAUSAL_LM:
                from core.llms.huggingface_model import HuggingFaceModel
                llm_instance = HuggingFaceModel(
                    model_name=model_name,
                    system_prompt=system_prompt,
                    quantization_bits=quantization_bits,
                    model_params=model_params,
                    override_system_by_user_template=override_system_by_user_template,
                    **other_llm_kwargs
                )
                func.log(f"Model '{model_name}' loaded as a Causal Language Model (HuggingFace).") 
            elif model_type == ModelType.SEQ2SEQ_LM:
                from core.llms.t5_model import T5Model
                llm_instance = T5Model(
                    model_name=model_name,
                    system_prompt=system_prompt,
                    quantization_bits=quantization_bits,
                    model_params=model_params,
                    override_system_by_user_template=override_system_by_user_template,
                    **other_llm_kwargs
                )
                func.log(f"Model '{model_name}' loaded as a Seq2Seq Language Model (T5-type).") 
            elif model_type == ModelType.OLLAMA:
                from core.llms.ollama_model import OllamaModel

                llm_instance = OllamaModel(
                    model_name=model_name,
                    system_prompt=system_prompt,
                    model_params=model_params,
                    override_system_by_user_template=override_system_by_user_template,
                    **other_llm_kwargs
                )
                func.log(f"Model '{model_name}' loaded as an Ollama Model.") 
            elif model_type == ModelType.GGUF:

                import ctypes
                from llama_cpp import llama_log_set
                def my_log_callback(level, message, user_data):
                    pass

                log_callback = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_char_p, ctypes.c_void_p)(my_log_callback)
                llama_log_set(log_callback, ctypes.c_void_p())
                
                gguf_filename = model_properties.get("gguf_filename")
                model_repo_id = model_properties.get("model_repo_id")
                n_ctx = model_properties.get("n_ctx")
                n_gpu_layers = model_properties.get("n_gpu_layers", -1)
                verbose = model_properties.get("verbose", False)

                if not gguf_filename:
                    func.log("'gguf_filename' is required for 'gguf' model_type in model properties.", level="ERROR") 
                    return None
                from core.llms.gguf_model import GGUFImageLLM
                llm_instance = GGUFImageLLM(
                    model_name=model_name,
                    gguf_filename=gguf_filename,
                    model_repo_id=model_repo_id,
                    system_prompt=system_prompt,
                    n_gpu_layers=n_gpu_layers,
                    n_ctx=n_ctx,
                    verbose=verbose,
                    model_params=model_params,
                    override_system_by_user_template=override_system_by_user_template,

                    **other_llm_kwargs
                )
                func.log(f"Model '{model_name}' loaded as a GGUF Image LLM.") 
            elif model_type == ModelType.GEMINI:
                from core.llms.gemini import GeminiAPIModel
                llm_instance = GeminiAPIModel(
                    model_name=model_name,
                    system_prompt=system_prompt,
                    use_vertex=model_params.get("vertex_ai", False),
                    model_params=model_params,
                    override_system_by_user_template=override_system_by_user_template,
                    **other_llm_kwargs
                )
                func.log(f"Model '{model_name}' loaded as a Gemini Model.")
            elif model_type == ModelType.OPEN_AI:
                from core.llms.open_ai import OpenAIAPIModel
                llm_instance = OpenAIAPIModel(
                    model_name=model_name,
                    system_prompt=system_prompt,
                    model_params=model_params,
                    override_system_by_user_template=override_system_by_user_template,

                    **other_llm_kwargs
                )
                func.log(f"Model '{model_name}' loaded as an OpenAI Model.")
            else:
                func.log(f"Unhandled model_type '{model_type.value}'.", level="ERROR")
                return None
        except Exception as e:
            func.error(f"Failed to instantiate model '{model_name}': {e}", level="ERROR")
            return None

        return llm_instance